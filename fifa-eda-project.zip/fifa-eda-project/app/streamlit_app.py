# app/streamlit_app.py
# PRO FIFA Dashboard — stacked Violin + Leaderboard (full-width)

import os
from pathlib import Path
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go

# ---------- Page config ----------
st.set_page_config(page_title="FIFA Analytics Channel", page_icon="⚽", layout="wide")

# ---------- Global CSS (polished look) ----------
st.markdown(
    """
    <style>
    :root {
      --bg-gradient: linear-gradient(180deg,#061426 0%, #08293e 60%);
      --card-bg: rgba(255,255,255,0.03);
      --muted: #bcdcff;
      --accent: #ffd166;
    }
    .stApp { background: var(--bg-gradient); color: #eaf3ff; font-family: Inter, ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial; }
    .hero { background: linear-gradient(90deg,#08304a,#0b4a6b); padding:18px; border-radius:12px; box-shadow:0 8px 28px rgba(0,0,0,0.45); margin-bottom:16px; }
    .kpi { background: var(--card-bg); padding:12px; border-radius:10px; text-align:center; min-height:84px; display:flex; flex-direction:column; justify-content:center; }
    .kpi .label { color:var(--muted); font-size:12px; }
    .kpi .value { color:#fff; font-size:20px; font-weight:800; margin-top:6px; }
    .card { background: var(--card-bg); padding:14px; border-radius:12px; box-shadow: 0 6px 20px rgba(0,0,0,0.35); margin-bottom:14px; }
    .card h3 { margin:0 0 8px 0; font-size:16px; font-weight:700; color:#eaf3ff; }
    .small-muted { color:var(--muted); font-size:12px; }
    .ticker { width:100%; overflow:hidden; white-space:nowrap; box-sizing:border-box; color:var(--accent); font-weight:700; margin-top:8px; }
    .stDataFrame table { border-collapse: collapse; }
    @media (max-width: 900px) { .hero { padding:12px; } .kpi { min-height:72px; } }
    </style>
    """, unsafe_allow_html=True
)

# ---------- Data loading ----------
CANDIDATES = [
    "data/processed/fifa_sample.csv",
    "data/processed/updated_fifa_sample.csv",
    "data/raw/fifa_sample_raw.csv",
    "../data/processed/fifa_sample.csv",
    "/mnt/data/updated_fifa_sample.csv"
]

df = None
used_path = None
for p in CANDIDATES:
    if Path(p).exists():
        try:
            df = pd.read_csv(p)
            used_path = p
            break
        except Exception:
            continue

if df is None:
    st.error("Could not find fifa_sample.csv. Put it into data/processed/ and restart the app.")
    st.stop()

# normalize column names
df.columns = [c.strip().lower().replace(" ", "_").replace("-", "_") for c in df.columns]

# canonical mapping
col_map = {}
for c in df.columns:
    if "player" in c and "name" in c:
        col_map[c] = "player_name"
    if c == "player":
        col_map[c] = "player_name"
    if c in ("team", "club", "country"):
        col_map[c] = "team"
    if "goal" in c and "per" not in c:
        col_map[c] = "goals"
    if c in ("assists", "assist"):
        col_map[c] = "assists"
    if "pass" in c and ("acc" in c or "accuracy" in c):
        col_map[c] = "pass_accuracy"
    if c in ("minutes", "minutes_played", "mins"):
        col_map[c] = "minutes_played"
    if "shots" in c and "on" in c:
        col_map[c] = "shots_on_target"
    if "possession" in c:
        col_map[c] = "possession_pct"
    if "position" in c and len(c) < 30:
        col_map[c] = "position"

df = df.rename(columns=col_map)

# ensure numeric fields exist
for c in ["minutes_played", "goals", "assists", "shots_on_target", "pass_accuracy", "tackles", "saves", "possession_pct"]:
    if c not in df.columns:
        df[c] = 0

# derived
if "goals_per_90" not in df.columns:
    df["goals_per_90"] = df.apply(lambda r: (r["goals"] * 90 / r["minutes_played"]) if r["minutes_played"] > 0 else 0, axis=1)

# ensure player_name
if "player_name" not in df.columns:
    df = df.rename(columns={df.columns[0]: "player_name"})

# ---------- Sidebar controls ----------
with st.sidebar:
    st.markdown("## ⚙️ Controls")
    team_opts = ["All"] + (sorted(df["team"].dropna().unique().tolist()) if "team" in df.columns else [])
    selected_team = st.selectbox("Team filter", team_opts)

    pos_opts = ["All"] + (sorted(df["position"].dropna().unique().tolist()) if "position" in df.columns else [])
    selected_position = st.selectbox("Position", pos_opts)

    show_debug = st.checkbox("Show debug", value=False)
    st.markdown("---")
    st.markdown("### Player compare")
    players = sorted(df["player_name"].dropna().unique().tolist())
    p1 = st.selectbox("Player A", ["(auto)"] + players, index=0)
    p2 = st.selectbox("Player B", ["(auto)"] + players, index=1 if len(players) > 1 else 0)
    st.markdown("---")
    st.markdown("### Quick stats")
    if "goals" in df.columns:
        top_scorer = df.groupby("player_name")["goals"].sum().idxmax()
        top_goals = int(df.groupby("player_name")["goals"].sum().max())
        st.markdown(f"**⚽ Top Scorer:** {top_scorer}")
        st.markdown(f"**Goals:** {top_goals}")

# ---------- Apply filters ----------
view = df.copy()
if selected_team != "All" and "team" in view.columns:
    view = view[view["team"] == selected_team]
if selected_position != "All" and "position" in view.columns:
    view = view[view["position"] == selected_position]

# auto-select players if auto chosen
if p1 == "(auto)" or p2 == "(auto)":
    top_series = df.groupby("player_name")["goals"].sum().sort_values(ascending=False)
    if len(top_series) > 0:
        if p1 == "(auto)":
            p1 = top_series.index[0]
        if p2 == "(auto)":
            p2 = top_series.index[1] if len(top_series) > 1 else top_series.index[0]

# ---------- Hero (full width) ----------
top_by_goals = df.groupby("player_name")["goals"].sum().sort_values(ascending=False)
top_player = top_by_goals.index[0] if len(top_by_goals) > 0 else "N/A"
top_goals = int(top_by_goals.iloc[0]) if len(top_by_goals) > 0 else 0
top_team = df[df["player_name"] == top_player]["team"].mode().iloc[0] if "team" in df.columns and top_player in df["player_name"].values else "N/A"

st.markdown(
    f"""
    <div class="hero">
      <div style="display:flex; align-items:center; justify-content:space-between; gap:18px;">
        <div style="display:flex; align-items:center; gap:16px;">
          <div style="background:linear-gradient(135deg,#ffd166,#ff8c42); padding:12px 14px; border-radius:10px; text-align:center;">
            <div style="font-size:28px; font-weight:800; color:#021a2b;">⭐</div>
          </div>
          <div>
            <div style="font-size:14px; color:#ffd166; font-weight:800;">🏆 LEADING SCORER</div>
            <div style="font-size:20px; font-weight:800;">{top_player}</div>
            <div class="small-muted">Team: <strong style="color:#fff">{top_team}</strong> • Goals: <strong style="color:#ffd166">{top_goals}</strong></div>
          </div>
        </div>
        <div style="text-align:right;">
          <div style="font-size:22px; font-weight:800; color:#ffd166;">{top_goals}</div>
          <div class="small-muted">TOTAL GOALS</div>
        </div>
      </div>
    </div>
    """, unsafe_allow_html=True
)

st.markdown("")  # spacing

# ---------- KPI row ----------
k1, k2, k3, k4 = st.columns([1, 1, 1, 1], gap="small")
with k1:
    matches = view["match_id"].nunique() if "match_id" in view.columns else "N/A"
    st.markdown(f'<div class="kpi"><div class="label">MATCHES</div><div class="value">{matches}</div></div>', unsafe_allow_html=True)
with k2:
    st.markdown(f'<div class="kpi"><div class="label">PLAYERS</div><div class="value">{view["player_name"].nunique()}</div></div>', unsafe_allow_html=True)
with k3:
    st.markdown(f'<div class="kpi"><div class="label">TOTAL GOALS</div><div class="value">{int(view["goals"].sum())}</div></div>', unsafe_allow_html=True)
with k4:
    avg_pass = view["pass_accuracy"].mean() if "pass_accuracy" in view.columns else 0
    st.markdown(f'<div class="kpi"><div class="label">AVG PASS ACC</div><div class="value">{avg_pass:.1f}%</div></div>', unsafe_allow_html=True)

st.markdown("---")

# ---------- Precompute aggregations ----------
player_goals = view.groupby("player_name", as_index=False)["goals"].sum().sort_values("goals", ascending=False)
top_goals_df = player_goals.head(12)

# ---------- Main grid: left (charts) / right (side) ----------
left, right = st.columns([2.2, 1.0], gap="large")

# LEFT: Top scorers + Pass scatter
with left:
    st.markdown('<div class="card"><h3>Top Goal Scorers</h3>', unsafe_allow_html=True)
    fig_bar = px.bar(
        top_goals_df, x="player_name", y="goals", text="goals",
        color="goals", color_continuous_scale="turbo", template="plotly_dark",
        labels={"player_name":"Player", "goals":"Goals"}
    )
    fig_bar.update_traces(textposition="outside", marker_line_width=0)
    fig_bar.update_layout(height=420, margin=dict(l=8, r=8, t=36, b=8), paper_bgcolor='rgba(0,0,0,0)')
    fig_bar.update_xaxes(tickangle=-35, tickfont=dict(size=11), automargin=True)
    st.plotly_chart(fig_bar, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

    st.markdown('<div class="card"><h3>Pass Accuracy vs Goals per 90</h3>', unsafe_allow_html=True)
    if "pass_accuracy" in view.columns and "goals_per_90" in view.columns:
        fig_scatter = px.scatter(
            view, x="pass_accuracy", y="goals_per_90",
            color="position" if "position" in view.columns else None,
            hover_data=["player_name", "team"],
            template="plotly_dark",
            labels={"pass_accuracy":"Pass Accuracy (%)", "goals_per_90":"Goals / 90"}
        )
        fig_scatter.update_layout(height=380, margin=dict(l=8, r=8, t=36, b=8), paper_bgcolor='rgba(0,0,0,0)')
        fig_scatter.update_traces(marker=dict(size=8, line=dict(width=0.3, color='rgba(255,255,255,0.05)')))
        st.plotly_chart(fig_scatter, use_container_width=True)
    else:
        st.info("pass_accuracy or goals_per_90 missing.")
    st.markdown("</div>", unsafe_allow_html=True)

# RIGHT: small highlights / spare (kept minimal for balance)
with right:
    st.markdown('<div class="card"><h3>Leader Highlights</h3>', unsafe_allow_html=True)
    if not player_goals.empty:
        leader = player_goals.iloc[0]["player_name"]
        leader_goals = int(player_goals.iloc[0]["goals"])
        st.markdown(f"**Top scorer:** {leader} — {leader_goals} goals")
    st.markdown(f"**Avg goals per player:** {view['goals'].mean():.2f}")
    st.markdown("</div>", unsafe_allow_html=True)

# ---------- NEW: Full-width Violin (stacked) ----------
st.markdown("---")
st.markdown('<div class="card"><h3>🎻 Goals Distribution by Position</h3>', unsafe_allow_html=True)

if "position" in view.columns and "goals" in view.columns:
    fig_violin = px.violin(
        view, x="position", y="goals", color="position",
        box=True, points="outliers", template="plotly_dark",
        labels={"position":"Position", "goals":"Goals"}
    )
    fig_violin.update_layout(height=420, margin=dict(l=8, r=8, t=36, b=8), showlegend=False, paper_bgcolor='rgba(0,0,0,0)')
    fig_violin.update_xaxes(tickangle=-20)
    st.plotly_chart(fig_violin, use_container_width=True)
else:
    st.info("Position or goals column missing.")
st.markdown("</div>", unsafe_allow_html=True)

# ---------- NEW: Full-width Leaderboard (stacked beneath violin) ----------
st.markdown("---")
st.markdown('<div class="card"><h3>🏅 Leaderboard (Top Scorers)</h3>', unsafe_allow_html=True)

goals_df = df.groupby("player_name", as_index=False)["goals"].sum().rename(columns={"goals":"total_goals"})
team_df = df.groupby("player_name", as_index=False)["team"].agg(lambda x: x.mode().iloc[0] if not x.mode().empty else "N/A")
lb_df = goals_df.merge(team_df, on="player_name").sort_values("total_goals", ascending=False).reset_index(drop=True)
lb_df.index = lb_df.index + 1

# compact display and download
st.dataframe(lb_df.head(20).rename(columns={"player_name":"Player","total_goals":"Goals","team":"Team"}), height=360)
csv_bytes = lb_df.to_csv(index=False).encode()
st.download_button("⬇️ Download Leaderboard CSV", data=csv_bytes, file_name="leaderboard.csv", mime="text/csv")
st.markdown("</div>", unsafe_allow_html=True)

# ---------- Player compare (full width) ----------
st.markdown("---")
st.markdown('<div class="card"><h3>⚔️ Player Comparison & Profile</h3>', unsafe_allow_html=True)

def get_player_summary(df_local, player):
    sub = df_local[df_local["player_name"] == player]
    if sub.empty:
        return None
    return {
        "Goals": int(sub["goals"].sum()),
        "Assists": int(sub["assists"].sum()) if "assists" in sub.columns else 0,
        "Shots": int(sub["shots_on_target"].sum()) if "shots_on_target" in sub.columns else 0,
        "PassAcc": float(sub["pass_accuracy"].mean()) if "pass_accuracy" in sub.columns else 0.0,
        "G_per_90": float(sub["goals_per_90"].mean()) if "goals_per_90" in sub.columns else 0.0
    }

pa = get_player_summary(df, p1)
pb = get_player_summary(df, p2)

colA, colB, colC = st.columns([1, 0.2, 1], gap="small")
with colA:
    st.markdown(f"### {p1}")
    if pa:
        st.write(f"**Goals:** {pa['Goals']}  ·  **Assists:** {pa['Assists']}")
        st.write(f"**Pass Acc:** {pa['PassAcc']:.1f}%  ·  **G/90:** {pa['G_per_90']:.2f}")
with colB:
    st.markdown("### VS")
with colC:
    st.markdown(f"### {p2}")
    if pb:
        st.write(f"**Goals:** {pb['Goals']}  ·  **Assists:** {pb['Assists']}")
        st.write(f"**Pass Acc:** {pb['PassAcc']:.1f}%  ·  **G/90:** {pb['G_per_90']:.2f}")

if pa and pb:
    radar_df = pd.DataFrame([pa, pb], index=[p1, p2])
    categories = radar_df.columns.tolist()
    def radar_fig(series, name):
        vals = series.values.tolist() + [series.values.tolist()[0]]
        cats = categories + [categories[0]]
        fig = go.Figure(data=[go.Scatterpolar(r=vals, theta=cats, fill='toself', name=name)])
        fig.update_layout(template="plotly_dark", height=420, polar=dict(radialaxis=dict(visible=True)))
        return fig

    fig_r = radar_fig(radar_df.loc[p1], p1)
    fig_r.add_trace(go.Scatterpolar(
        r=radar_df.loc[p2].values.tolist() + [radar_df.loc[p2].values.tolist()[0]],
        theta=categories + [categories[0]], fill='toself', name=p2
    ))
    st.plotly_chart(fig_r, use_container_width=True)
else:
    st.info("Pick two players with sufficient data to compare")

st.markdown("</div>", unsafe_allow_html=True)

# ---------- Attribute distribution (full width) ----------
st.markdown("---")
st.markdown('<div class="card"><h3>📊 Player Attribute Distribution</h3>', unsafe_allow_html=True)

attribute_options = ["goals", "assists", "shots_on_target", "pass_accuracy", "goals_per_90", "tackles", "saves"]
available_attrs = [a for a in attribute_options if a in view.columns]
if available_attrs:
    selected_attr = st.selectbox("Select attribute to display:", available_attrs, index=0)
    fig_hist = px.histogram(
        view, x=selected_attr, nbins=25,
        color="position" if "position" in view.columns else None,
        template="plotly_dark",
        labels={selected_attr: selected_attr.replace("_", " ").title()}
    )
    fig_hist.update_layout(height=420, margin=dict(l=8, r=8, t=36, b=8), paper_bgcolor='rgba(0,0,0,0)')
    st.plotly_chart(fig_hist, use_container_width=True)
else:
    st.info("No numeric attributes available for distribution.")
st.markdown("</div>", unsafe_allow_html=True)

# ---------- Bottom ticker ----------
st.markdown(f'<div class="ticker">LIVE • Top Scorer: {top_player} — {top_goals} goals • Stream built with Streamlit</div>', unsafe_allow_html=True)

# ---------- Debug panel ----------
if show_debug:
    st.markdown("---")
    st.subheader("DEBUG")
    st.write("Data path:", used_path)
    st.write("Columns:", df.columns.tolist())
    st.dataframe(df.head(10))
