import pandas as pd
import numpy as np

df = pd.read_csv("data/raw/fifa_sample.csv")

df = df.drop_duplicates()
df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
df = df[df['Date'].notna()]

df['Goals_per_90'] = df['Goals'] * 90 / df['Minutes_Played'].replace(0, np.nan)
df['Assists_per_90'] = df['Assists'] * 90 / df['Minutes_Played'].replace(0, np.nan)
df['Outcome_Label'] = df['Outcome'].map({'Win':2,'Draw':1,'Loss':0})

df.to_csv("data/processed/fifa_sample.csv", index=False)
print("✅ Cleaned data saved to data/processed/fifa_sample.csv")
