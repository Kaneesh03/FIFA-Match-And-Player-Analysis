import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta

random.seed(42)
np.random.seed(42)

teams = ["Brazil","Germany","Argentina","France","Spain","England","Portugal","Netherlands","Belgium","Italy"]
positions = ["Forward","Midfielder","Defender","Goalkeeper"]
players = [f"Player_{i}" for i in range(1,51)]  # 50 players

rows = []
start_date = datetime(2024,6,1)
match_id = 1

for i in range(100):  # ~100 rows
    date = (start_date + timedelta(days=random.randint(0,365))).strftime("%Y-%m-%d")
    team = random.choice(teams)
    opponent = random.choice([t for t in teams if t != team])
    player = random.choice(players)
    position = random.choices(positions, weights=[0.25,0.35,0.3,0.1])[0]
    minutes = int(np.clip(np.random.normal(70, 20), 0, 90))

    if position == "Forward":
        goals = np.random.poisson(0.4)
        assists = np.random.poisson(0.2)
        shots_on_target = np.random.poisson(1.2)
    elif position == "Midfielder":
        goals = np.random.poisson(0.15)
        assists = np.random.poisson(0.25)
        shots_on_target = np.random.poisson(0.6)
    elif position == "Defender":
        goals = np.random.poisson(0.05)
        assists = np.random.poisson(0.05)
        shots_on_target = np.random.poisson(0.2)
    else:
        goals = 0
        assists = 0
        shots_on_target = 0

    pass_acc = float(np.clip(np.random.normal(78 if position!="Forward" else 72, 8), 40, 99))
    tackles = int(np.random.poisson(2 if position!="Forward" else 0.5))
    saves = int(np.random.poisson(3 if position=="Goalkeeper" else 0))
    possession = float(np.clip(np.random.normal(50,12), 20, 80))

    if goals > 1:
        outcome = "Win"
    elif goals == 1:
        outcome = "Draw"
    else:
        outcome = "Loss"

    rows.append({
        "Match_ID": match_id,
        "Date": date,
        "Team": team,
        "Opponent": opponent,
        "Player_Name": player,
        "Position": position,
        "Minutes_Played": minutes,
        "Goals": int(goals),
        "Assists": int(assists),
        "Shots_on_Target": int(shots_on_target),
        "Pass_Accuracy": round(pass_acc,1),
        "Tackles": tackles,
        "Saves": saves,
        "Possession_pct": round(possession,1),
        "Outcome": outcome
    })
    if np.random.rand() < 0.3:
        match_id += 1

df = pd.DataFrame(rows)
df.to_csv("data/raw/fifa_sample_raw.csv", index=False)
print("✅ Data generated and saved to data/raw/fifa_sample_raw.csv")
